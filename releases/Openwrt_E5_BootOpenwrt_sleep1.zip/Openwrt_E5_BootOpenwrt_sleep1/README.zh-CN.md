# 从 Android 切回 OpenWrt（e5-sleep1 内核专用）

设备 boot_b 已刷入深度休眠内核 `6.18.54-e5-sleep1`（看门狗挂起修复、显示驱动修复、cpuidle）。
原版刷机包的 `--boot-openwrt` 会因 boot_b 哈希不同而拒绝，这个包配的是新内核的 boot.json。

只支持一个命令（其他命令会被拒绝；这个包没有 rootfs 镜像，不能安装或更新）：

    flash.cmd --boot-openwrt        (Windows；macOS / Linux：./flash.sh --boot-openwrt)

也可以用 Magisk 的 E5 Linux 切回模块，它不校验内核哈希。

## 回到原版内核（e5-mobile4）

在 Android 里（adb + Magisk root）：

    adb shell su -c sh /data/e5linux/restore-boot-b.sh

它把备份 /data/e5linux/boot_b-mobile4.img 校验后写回 boot_b，之后用**原版**刷机包的
`flash.cmd --boot-openwrt` 切回。新内核的模块目录
/lib/modules/6.18.54-e5-sleep1-00072-g020b970e351e-dirty 留在 rootfs 里不影响原版内核。

原版刷机包的 `--update` 会把 boot_b 换回原版内核，同时保留设置。
